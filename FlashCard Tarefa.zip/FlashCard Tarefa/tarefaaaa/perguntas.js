criaCartao(
    'Crustáceos',
    'Você sabia?',
    'A lagosta tem sua pele vermelha devido ao calor, que da o pigmento vermelho-alaranjado para sua casca.'
)

criaCartao(
    'Tubarões',
    'Você sabia?',
    'Os tubarões podem viver centenas de anos.'
)

criaCartao(
    'Planctons',
    'Você sabia?',
    'O plâncton é um organismo microscópico que pode ser encontrado em todos os ambientes aquáticos, desde a água doce até os mares.'
)

criaCartao(
    'Peixes',
    'Você sabia?',
    'Os peixes-espada adultos não têm dentes.'
)